﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CompMacro11
{
    // ── Панель номеров строк ──────────────────────────────────────
    // Располагается слева от RichTextBox.
    // Синхронизируется через GetFirstCharIndexFromLine + GetPositionFromCharIndex.
    public class LineNumPanel : Panel
    {
        private RichTextBox _rtb;
        public int ErrorLine { get; set; } = -1;

        private static readonly Color BG = Color.FromArgb(30, 30, 30);
        private static readonly Color FG = Color.FromArgb(100, 100, 100);
        private static readonly Color FG_ERR = Color.FromArgb(240, 100, 80);
        private static readonly Color BG_ERR = Color.FromArgb(90, 25, 25);

        public LineNumPanel(RichTextBox rtb)
        {
            _rtb = rtb;
            Width = 46;
            Dock = DockStyle.Left;
            BackColor = BG;
            DoubleBuffered = true;

            // Перерисовывать при прокрутке и изменении текста редактора
            _rtb.VScroll += (s, e) => Invalidate();
            _rtb.TextChanged += (s, e) => Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.FillRectangle(new SolidBrush(BG), ClientRectangle);

            if (_rtb.Lines.Length == 0) return;

            var font = _rtb.Font;
            var sfmt = new StringFormat
            {
                Alignment = StringAlignment.Far,
                LineAlignment = StringAlignment.Near
            };

            int lineCount = _rtb.Lines.Length;
            for (int i = 0; i < lineCount; i++)
            {
                int charIdx = _rtb.GetFirstCharIndexFromLine(i);
                if (charIdx < 0) break;
                Point pt = _rtb.GetPositionFromCharIndex(charIdx);

                // Учесть что Panel смещена левее RichTextBox — Y совпадает
                if (pt.Y + font.Height < 0) continue;
                if (pt.Y > _rtb.Height) break;

                int lineNum = i + 1;
                bool isErr = lineNum == ErrorLine;

                if (isErr)
                    g.FillRectangle(new SolidBrush(BG_ERR),
                        0, pt.Y, Width, font.Height + 1);

                var rc = new RectangleF(0, pt.Y, Width - 4, font.Height);
                g.DrawString(lineNum.ToString(), font,
                    new SolidBrush(isErr ? FG_ERR : FG), rc, sfmt);
            }

            sfmt.Dispose();
        }
    }

    public partial class Form1 : Form
    {
        // ── WinAPI для Undo/Redo в RichTextBox ───────────────────
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        private const int WM_SETREDRAW = 0x000B;

        // ── Сохранение/восстановление позиции прокрутки ──────────
        // Установка SelectionStart прокручивает RichTextBox к каретке.
        // WM_SETREDRAW гасит только перерисовку, но не саму прокрутку,
        // поэтому после подсветки вид уезжал к курсору. Запоминаем
        // позицию до покраски и возвращаем перед включением отрисовки.
        private const int EM_GETSCROLLPOS = 0x04DD;
        private const int EM_SETSCROLLPOS = 0x04DE;

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam,
                                                 ref System.Drawing.Point lParam);

        private static System.Drawing.Point GetRtbScroll(RichTextBox rtb)
        {
            var p = System.Drawing.Point.Empty;
            SendMessage(rtb.Handle, EM_GETSCROLLPOS, IntPtr.Zero, ref p);
            return p;
        }

        private static void SetRtbScroll(RichTextBox rtb, System.Drawing.Point p)
        {
            SendMessage(rtb.Handle, EM_SETSCROLLPOS, IntPtr.Zero, ref p);
        }

        private static void BeginRtbUpdate(RichTextBox rtb) =>
            SendMessage(rtb.Handle, WM_SETREDRAW, IntPtr.Zero, IntPtr.Zero);
        private static void EndRtbUpdate(RichTextBox rtb)
        {
            SendMessage(rtb.Handle, WM_SETREDRAW, new IntPtr(1), IntPtr.Zero);
            rtb.Invalidate();
        }

        // ── Цвета ─────────────────────────────────────────────────
        static readonly Color C_BG = Color.FromArgb(28, 28, 28);
        static readonly Color C_BG2 = Color.FromArgb(37, 37, 38);
        static readonly Color C_BG3 = Color.FromArgb(22, 22, 22);
        static readonly Color C_TEXT = Color.FromArgb(212, 212, 212);
        static readonly Color C_KEYWORD = Color.FromArgb(86, 156, 214);
        static readonly Color C_NUMBER = Color.FromArgb(181, 206, 168);
        static readonly Color C_COMMENT = Color.FromArgb(106, 153, 85);
        static readonly Color C_TYPE = Color.FromArgb(78, 201, 176);
        static readonly Color C_ACCENT = Color.FromArgb(0, 122, 204);
        static readonly Color C_ERROR = Color.FromArgb(240, 100, 80);
        static readonly Color C_OK = Color.FromArgb(78, 201, 176);
        static readonly Color C_GRAY = Color.FromArgb(120, 120, 120);

        static readonly Font F_MONO = new Font("Consolas", 10.5f);
        static readonly Font F_UI = new Font("Segoe UI", 9f);
        static readonly Font F_UI_B = new Font("Segoe UI", 9f, FontStyle.Bold);

        // ── Контролы ──────────────────────────────────────────────
        private RichTextBox _src;
        private RichTextBox _out;
        private string _lastGenerated = null;   // что компилятор сгенерировал в _out последний раз
        private LineNumPanel _linePanel;
        private Label _status;
        private Panel _statusBar;
        private Label _statusInfo;
        private Label _statusPos;
        private bool _highlighting;
        private System.Windows.Forms.Timer _hlTimer;
        private System.Windows.Forms.Timer _scrollTimer;
        private SpriteEditor _spriteEditor;
        private ToolTip _toolTip = new ToolTip();
        private LevelEditor _levelEditor;
        private ImageConverter _imageConverter;
        private string _emulatorPath = "";   // путь к UKNCBTL.exe
        private McProject _project = null;   // текущий проект
        private string _projectSpritesPath = null;
        private string _projectLevelsPath = null;
        // Пока true, изменения _src.Text не помечают проект изменённым
        // (используется при загрузке кода из проекта).
        private bool _suppressDirty = false;
        private int _lastSpriteBytes = 0;   // размер подключённых спрайтов (байт УКНЦ)
        private Button _btnSave = null;
        private CheckBox _chkOptimize = null;   // tree-shaking рантайма

        public Form1()
        {
            InitializeComponent();
            BuildUI();
            // Загружаем путь к эмулятору из окружения этой машины
            _emulatorPath = AppEnvironment.EmulatorPath;
        }

        private void BuildUI()
        {
            Text = "Mini-C → Macro-11";
            Size = new Size(1360, 820);
            MinimumSize = new Size(900, 600);
            BackColor = C_BG;
            Font = F_UI;
            KeyPreview = true;
            KeyDown += OnKeyDown;
            FormClosing += (_, __) => AppEnvironment.LastCode = _src.Text;

            // ── Toolbar ───────────────────────────────────────────
            var bar = new Panel { Dock = DockStyle.Top, Height = 46, BackColor = C_BG2 };

            var btnCompile = MakeBtn("▶  Компилировать  [F5]", 190, C_ACCENT, 8);
            _toolTip.SetToolTip(btnCompile, "Собрать .mac и показать результат (F5)");
            btnCompile.Click += (_, __) => Compile();

            var btnClear = MakeBtn("✕", 36, Color.FromArgb(60, 60, 60), 206);
            _toolTip.SetToolTip(btnClear, "Очистить редактор кода и вывод");
            btnClear.Font = new Font("Segoe UI", 12f);
            btnClear.Click += (_, __) =>
            {
                _src.Clear(); _out.Clear();
                _linePanel.ErrorLine = -1;
                _linePanel.Invalidate();
                SetStatus("", false);
            };

            var btnExample = MakeBtn("Примеры ▾", 95, Color.FromArgb(60, 60, 60), 250);
            _toolTip.SetToolTip(btnExample, "Готовые примеры программ");
            btnExample.Click += (_, __) => ShowExamplesMenu(btnExample);


            var btnRun = MakeBtn("▶ Эмулятор", 105, Color.FromArgb(30, 90, 50), 353);
            _toolTip.SetToolTip(btnRun, "Собрать и сразу открыть в UKNCBTL");
            btnRun.Click += (_, __) => RunInEmulator();

            // Чекбокс оптимизации больше не показывается в баре —
            // его состояние хранится здесь, а управление перенесено
            // в меню «Настройки». Создаём без добавления в bar.Controls.
            // Оптимизация рантайма (вырезание неиспользуемых блоков) снова
            // управляется вручную: она режет .mac по меткам, и внутренние
            // метки буферного пути вывода могут попасть под нож.
            _chkOptimize = new CheckBox
            {
                Text = "Оптим.",
                Checked = true,
                AutoSize = true,
                Location = new Point(1102, 16),
                ForeColor = Color.FromArgb(190, 190, 190),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9f),
                Cursor = Cursors.Hand
            };
            _toolTip.SetToolTip(_chkOptimize, "Вырезать неиспользуемые блоки рантайма из .mac");
            _chkOptimize.CheckedChanged += (_, __) =>
                SetStatus(_chkOptimize.Checked
                    ? "✓  Оптимизация рантайма включена"
                    : "○  Оптимизация рантайма выключена — .mac собирается целиком", false);

            // Режим компиляции виден всегда: переключатель стоит прямо в
            // панели, на месте прежней кнопки «Настройки». Само меню убрано,
            // а оптимизация рантайма остаётся включённой (_chkOptimize).
            _modeLabel = new Label
            {
                Text = "Режим:",
                Location = new Point(926, 16),
                AutoSize = true,
                ForeColor = Color.FromArgb(190, 190, 190),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9f)
            };
            _modeSwitch = new ModeSwitch { Location = new Point(982, 12) };
            _modeSwitch.SetState(_gameMode);
            _toolTip.SetToolTip(_modeSwitch, "Переключить режим ЦП / Game");
            _modeSwitch.Toggled += g =>
            {
                _gameMode = g;
                if (_project != null && _project.Settings.GameMode != g)
                {
                    _project.Settings.GameMode = g;
                    MarkProjectDirty();
                }
                UpdateTitle();
                SetStatus(g
                    ? "✓  Режим Game: 320x264, спрайты, ЦП+ПП (8 цветов)"
                    : "✓  Режим ЦП: векторная графика, 4 цвета", false);
            };

            var btnHelp = MakeBtn("?", 32, Color.FromArgb(50, 80, 120), 466);
            _toolTip.SetToolTip(btnHelp, "Справка по языку и платформе");
            btnHelp.Font = new Font("Segoe UI", 11f, FontStyle.Bold);
            btnHelp.Click += (_, __) => ShowHelp();

            var btnSprites = MakeBtn("🎨 Спрайты", 100, Color.FromArgb(60, 40, 80), 506);
            _toolTip.SetToolTip(btnSprites, "Редактор спрайтов проекта");
            btnSprites.Click += (_, __) =>
            {
                if (_spriteEditor == null || _spriteEditor.IsDisposed)
                {
                    _spriteEditor = new SpriteEditor(code =>
                    {
                        string text = _src.Text;

                        // Удалить старый блок комментариев спрайтов если есть
                        // Блок начинается с "// ── Спрайты" и заканчивается
                        // перед первой непустой некомментарной строкой
                        var startMatch = Regex.Match(text,
                            @"// ── Спрайты[^\n]*\n(// [^\n]*\n)*");
                        if (startMatch.Success)
                        {
                            text = text.Substring(0, startMatch.Index)
                                 + text.Substring(startMatch.Index + startMatch.Length);
                        }

                        // Вставить новый блок в начало
                        _src.Text = code + "\n" + text;
                        _src.SelectionStart = 0;
                        Highlight();
                    });
                    // Синхронизируем путь файла спрайтов с тем, откуда читает
                    // компилятор (проектный sprites/sprites.spr или автосейв).
                    // Иначе редактор сохранял бы в одно место, а компилятор
                    // читал из другого → "спрайт не найден" при закрытом редакторе.
                    UpdateSpritesPath();
                }
                if (_spriteEditor.Visible)
                    _spriteEditor.BringToFront();
                else
                    _spriteEditor.Show(this);
            };

            var btnGames = MakeBtn("🎮 Игры ▾", 90, Color.FromArgb(40, 60, 80), 606);
            _toolTip.SetToolTip(btnGames, "Редакторы уровней для игр проекта");
            btnGames.Click += (_, __) =>
            {
                var menu = new ContextMenuStrip();
                menu.BackColor = Color.FromArgb(45, 45, 48);
                menu.ForeColor = Color.White;

                var miBattleCity = new ToolStripMenuItem("🏰 Battle City");
                miBattleCity.Click += (s2, e2) => OpenLevelEditor();
                menu.Items.Add(miBattleCity);
                // сюда позже добавятся редакторы уровней других игр —
                // тем же способом, каждая своим пунктом меню.

                menu.Items.Add(new ToolStripSeparator());
                var miImgConv = new ToolStripMenuItem("🖼 Картинка → УКНЦ (тест)");
                miImgConv.Click += (s2, e2) => OpenImageConverter();
                menu.Items.Add(miImgConv);

                menu.Show(btnGames, new System.Drawing.Point(0, btnGames.Height));
            };

            _status = new Label
            {
                Text = "",
                Height = 32,
                Font = F_UI_B,
                ForeColor = C_GRAY,
                BackColor = Color.Transparent,
                AutoSize = false,
                TextAlign = System.Drawing.ContentAlignment.MiddleRight,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
            };
            bar.SizeChanged += (_, __) =>
            {
                _status.Width = bar.Width - 1085;
                _status.Location = new Point(1176, 7);
            };

            // ── Меню Проект ───────────────────────────────────────
            var btnDisk = MakeBtn("💾 Диск", 90, Color.FromArgb(50, 55, 75), 710);
            _toolTip.SetToolTip(btnDisk, "Работа с образом диска");
            btnDisk.Click += (_, __) =>
            {
                using (var d = new DskDialog()) d.ShowDialog(this);
            };

            var btnProject = MakeBtn("📁 Проект ▾", 110, Color.FromArgb(40, 70, 40), 808);
            _toolTip.SetToolTip(btnProject, "Открыть, создать, сохранить проект");
            btnProject.Click += (_, __) =>
            {
                var menu = new ContextMenuStrip();
                menu.BackColor = Color.FromArgb(45, 45, 48);
                menu.ForeColor = Color.White;

                var miNew = new ToolStripMenuItem("Новый проект...");
                var miOpen = new ToolStripMenuItem("Открыть проект...");
                var miSave = new ToolStripMenuItem("Сохранить проект") { Enabled = _project != null };
                var miSaveAs = new ToolStripMenuItem("Сохранить как...") { Enabled = _project != null };
                var miClose = new ToolStripMenuItem("Закрыть проект") { Enabled = _project != null };
                var miRecent = new ToolStripMenuItem("Последние проекты");

                var recent = RecentProjects.Load();
                if (recent.Count == 0)
                    miRecent.DropDownItems.Add(new ToolStripMenuItem("(пусто)") { Enabled = false });
                else
                    foreach (var r in recent)
                    {
                        string rr = r;
                        var mi = new ToolStripMenuItem(System.IO.Path.GetFileNameWithoutExtension(rr));
                        mi.Click += (s2, e2) => ProjectOpen(rr);
                        miRecent.DropDownItems.Add(mi);
                    }

                miNew.Click += (s2, e2) => ProjectNew();
                miOpen.Click += (s2, e2) => ProjectOpenDialog();
                miSave.Click += (s2, e2) => ProjectSave();
                miSaveAs.Click += (s2, e2) => ProjectSaveAs();
                miClose.Click += (s2, e2) => ProjectClose();

                menu.Items.AddRange(new ToolStripItem[] { miNew, miOpen, new ToolStripSeparator(), miSave, miSaveAs, miClose, new ToolStripSeparator(), miRecent });
                menu.Show(btnProject, new System.Drawing.Point(0, btnProject.Height));
            };

            bar.Controls.AddRange(new Control[] { btnCompile, btnClear, btnExample, _modeLabel, _modeSwitch, _chkOptimize, btnRun, btnHelp, btnSprites, btnGames, btnDisk, btnProject, _status });

            // ── Заголовки ─────────────────────────────────────────
            var hdr = new Panel
            {
                Dock = DockStyle.Top,
                Height = 28,
                BackColor = Color.FromArgb(30, 30, 30)
            };
            hdr.Controls.Add(MakeLabel("  Mini-C  —  исходный код", 0));
            hdr.Controls.Add(MakeLabel("  Macro-11  —  результат", 650));

            var btnCopyHdr = new Button
            {
                Text = "📋 Копировать",
                Width = 110,
                Height = 22,
                Location = new Point(860, 3),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 50, 50),
                ForeColor = Color.FromArgb(180, 180, 180),
                Font = new Font("Segoe UI", 8f),
                Cursor = Cursors.Hand
            };
            btnCopyHdr.FlatAppearance.BorderSize = 0;
            btnCopyHdr.Click += (_, __) =>
            {
                if (string.IsNullOrEmpty(_out.Text)) return;
                Clipboard.SetText(_out.Text);
                btnCopyHdr.Text = "✔ Скопировано";
                btnCopyHdr.ForeColor = C_OK;
                var t = new System.Windows.Forms.Timer { Interval = 1500 };
                t.Tick += (s2, e2) =>
                {
                    btnCopyHdr.Text = "📋 Копировать";
                    btnCopyHdr.ForeColor = Color.FromArgb(180, 180, 180);
                    t.Stop(); t.Dispose();
                };
                t.Start();
            };
            hdr.Controls.Add(btnCopyHdr);

            // ── Разделитель ───────────────────────────────────────
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                BackColor = Color.FromArgb(55, 55, 55),
                SplitterWidth = 3,
                SplitterDistance = 620
            };
            // При первом показе установить 2/3 на редактор, 1/3 на ассемблер
            split.SizeChanged += (s, e) =>
            {
                if (split.Width > 0)
                {
                    int d = split.Width * 2 / 3;
                    if (d > split.Panel1MinSize && d < split.Width - split.Panel2MinSize)
                        split.SplitterDistance = d;
                }
            };

            // ── Левая панель: нумерация + редактор ────────────────
            _src = new RichTextBox
            {
                Dock = DockStyle.Fill,
                Font = F_MONO,
                BackColor = C_BG,
                ForeColor = C_TEXT,
                BorderStyle = BorderStyle.None,
                ScrollBars = RichTextBoxScrollBars.Both,
                WordWrap = false,
                AcceptsTab = true
            };
            // Дебаунс подсветки — 120мс после последнего нажатия (окно мало → быстро)
            _hlTimer = new System.Windows.Forms.Timer { Interval = 120 };
            _hlTimer.Tick += (_, __) => { _hlTimer.Stop(); Highlight(); };
            _src.TextChanged += (_, __) =>
            {
                if (!_highlighting) { _hlTimer.Stop(); _hlTimer.Start(); }
                if (!_suppressDirty) MarkProjectDirty();
            };
            // Перекрашивать при прокрутке — новые видимые строки (дебаунс 60мс)
            _scrollTimer = new System.Windows.Forms.Timer { Interval = 60 };
            _scrollTimer.Tick += (_, __) => { _scrollTimer.Stop(); Highlight(); };
            _src.VScroll += (_, __) => { if (!_highlighting) { _scrollTimer.Stop(); _scrollTimer.Start(); } };

            _linePanel = new LineNumPanel(_src);

            // Контейнер: Panel слева (номера) + RichTextBox справа
            var leftContainer = new Panel { Dock = DockStyle.Fill };
            leftContainer.Controls.Add(_src);        // Fill — занимает остаток
            leftContainer.Controls.Add(_linePanel);  // Left — прибивается слева

            // ── Правая панель ─────────────────────────────────────
            _out = new RichTextBox
            {
                Dock = DockStyle.Fill,
                Font = F_MONO,
                BackColor = C_BG3,
                ForeColor = C_TEXT,
                BorderStyle = BorderStyle.None,
                ScrollBars = RichTextBoxScrollBars.Both,
                WordWrap = false,
                ReadOnly = false
            };

            split.Panel1.Controls.Add(leftContainer);
            split.Panel2.Controls.Add(_out);

            // ── Статусбар внизу ───────────────────────────────────
            _statusBar = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 24,
                BackColor = C_ACCENT
            };
            _statusInfo = new Label
            {
                Dock = DockStyle.Fill,
                Text = "Готово",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 8.5f),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(8, 0, 0, 0),
                BackColor = Color.Transparent
            };
            _statusPos = new Label
            {
                Dock = DockStyle.Right,
                Width = 320,
                Text = "Стр 1, Кол 1",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 8.5f),
                TextAlign = ContentAlignment.MiddleRight,
                Padding = new Padding(0, 0, 10, 0),
                BackColor = Color.Transparent
            };
            _statusBar.Controls.Add(_statusInfo);
            _statusBar.Controls.Add(_statusPos);

            // обновление позиции курсора и счётчиков при изменениях
            _src.SelectionChanged += (_, __) => UpdateStatusBar();
            _src.TextChanged += (_, __) => UpdateStatusBar();

            // Порядок важен: Fill добавляется первым, Bottom/Top — после,
            // чтобы доки распределились корректно.
            Controls.Add(split);
            Controls.Add(_statusBar);
            Controls.Add(hdr);
            Controls.Add(bar);

            var lastProject = AppEnvironment.LastProjectPath;
            if (!string.IsNullOrEmpty(lastProject) && System.IO.File.Exists(lastProject))
            {
                // При старте открываем последний ПРОЕКТ целиком: код, путь к
                // спрайтам для редактора и режим ЦП/Game — всё через тот же
                // путь, что и обычное открытие проекта, ничего не дублируем.
                Load += (_, __) => ProjectOpen(lastProject);
            }
            else
            {
                var lastCode = AppEnvironment.LastCode;
                _src.Text = !string.IsNullOrEmpty(lastCode) ? lastCode : LoadSample();
            }
            Highlight();
            UpdateStatusBar();
        }

        // Обновляет нижний статусбар: позиция курсора, число строк/символов.
        private void UpdateStatusBar()
        {
            if (_statusPos == null || _src == null) return;
            int idx = _src.SelectionStart;
            int line = _src.GetLineFromCharIndex(idx);
            int lineStart = _src.GetFirstCharIndexFromLine(line);
            int col = idx - lineStart;
            int totalLines = _src.Lines.Length;
            int totalChars = _src.TextLength;
            _statusPos.Text = $"Стр {line + 1}, Кол {col + 1}   |   {totalLines} стр   |   {totalChars} симв";
        }

        // Показывает сообщение в нижнем статусбаре (например, размер .mac после компиляции).
        private void SetStatusBarInfo(string msg)
        {
            if (_statusInfo != null) _statusInfo.Text = msg;
        }

        // ── Хелперы UI ────────────────────────────────────────────
        private Button MakeBtn(string text, int w, Color bg, int x)
        {
            var b = new Button
            {
                Text = text,
                Width = w,
                Height = 32,
                Location = new Point(x, 7),
                FlatStyle = FlatStyle.Flat,
                BackColor = bg,
                ForeColor = Color.White,
                Font = F_UI_B,
                Cursor = Cursors.Hand
            };
            b.FlatAppearance.BorderSize = 0;
            return b;
        }

        private Label MakeLabel(string text, int x) => new Label
        {
            Text = text,
            Location = new Point(x, 5),
            Width = 400,
            Height = 20,
            Font = F_UI_B,
            ForeColor = C_GRAY,
            BackColor = Color.Transparent
        };

        // ── Справка ───────────────────────────────────────────────
        // Темы справки (для списка слева)
        private static readonly string[] HelpTopics = new[] { "Новое: рекурсия, константы", "Синтаксис языка", "Встроенные функции", "Вывод текста", "Позиция и цвет текста", "Графика (basicGraphic)", "Цвета", "Клавиши УКНЦ", "Экран УКНЦ", "Горячие клавиши" };

        private void ShowHelp()
        {
            var dlg = new Form
            {
                Text = "Справка — Mini-C для УКНЦ",
                Size = new Size(980, 680),
                MinimumSize = new Size(700, 460),
                BackColor = Color.FromArgb(28, 28, 28),
                ForeColor = Color.FromArgb(212, 212, 212),
                Font = F_UI,
                StartPosition = FormStartPosition.CenterParent,
                KeyPreview = true
            };
            dlg.KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) dlg.Close(); };

            // Правая панель — контент
            var rtb = new RichTextBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(28, 28, 28),
                ForeColor = Color.FromArgb(212, 212, 212),
                Font = new Font("Consolas", 10f),
                BorderStyle = BorderStyle.None,
                ReadOnly = true,
                WordWrap = true,
                ScrollBars = RichTextBoxScrollBars.Vertical,
                Margin = new Padding(0)
            };
            // Обёртка с отступом — иначе текст липнет прямо к краю окна
            var contentWrap = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(28, 28, 28), Padding = new Padding(16, 4, 8, 8) };
            contentWrap.Controls.Add(rtb);

            // Заголовок над содержимым — показывает текущий раздел,
            // тем же стилем, что и заголовок списка слева.
            var contentHdr = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = Color.FromArgb(45, 45, 48) };
            var contentHdrLbl = new Label
            {
                Text = "",
                Dock = DockStyle.Fill,
                ForeColor = Color.FromArgb(212, 212, 212),
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(16, 0, 0, 0)
            };
            contentHdr.Controls.Add(contentHdrLbl);

            // Левая панель — список тем
            var list = new ListBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(37, 37, 38),
                ForeColor = Color.FromArgb(212, 212, 212),
                Font = new Font("Segoe UI", 9.5f),
                BorderStyle = BorderStyle.None,
                IntegralHeight = false,
                ItemHeight = 26
            };
            foreach (var t in HelpTopics) list.Items.Add(t);
            list.SelectedIndexChanged += (_, __) =>
            {
                if (list.SelectedIndex < 0) return;
                rtb.Clear();
                FillTopic(rtb, list.SelectedIndex);
                rtb.SelectionStart = 0;
                rtb.ScrollToCaret();
                contentHdrLbl.Text = list.SelectedItem?.ToString() ?? "";
            };

            // Заголовок над списком
            var listHdr = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = C_ACCENT };
            listHdr.Controls.Add(new Label
            {
                Text = "  Разделы",
                Dock = DockStyle.Fill,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft
            });

            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(28, 28, 28),
                SplitterWidth = 3
            };
            split.Panel1.Controls.Add(list);
            split.Panel1.Controls.Add(listHdr);
            split.Panel2.Controls.Add(contentWrap);
            split.Panel2.Controls.Add(contentHdr);
            split.Panel1MinSize = 140;

            dlg.Controls.Add(split);
            split.SplitterDistance = 150;   // после добавления в форму — иначе SplitContainer ещё не знает свой настоящий размер и клеит значение не туда
            dlg.Show();
            list.SelectedIndex = 0;   // показать первую тему
        }

        // Заполняет правую панель содержимым выбранной темы.
        private void FillTopic(RichTextBox r, int idx)
        {
            switch (idx)
            {
                case 0:
                    HelpT(r, "\n═══ НОВОЕ: взаимная рекурсия и константы ═══════════════\n", Color.FromArgb(78, 201, 176));
                    HelpT(r, "\n  Forward-declaration (прототип функции):\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    Объявите функцию до её определения — точкой с запятой\n", C_TEXT);
                    HelpT(r, "    вместо тела. Позволяет ВЗАИМНУЮ РЕКУРСИЮ.\n\n", C_TEXT);
                    HelpT(r, "    int isOdd(int n);            // прототип\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    int isEven(int n) {\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        if (n == 0) return 1;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        return isOdd(n - 1);   // вызов до определения\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    }\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    int isOdd(int n) {\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        if (n == 0) return 0;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        return isEven(n - 1);\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    }\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Константы — два способа:\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "\n    #define WIDTH 320          // препроцессор\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    #define COLOR 3\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    const int CENTER = 160;     // типизированная\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    Имя заменяется значением до компиляции. Удобно для\n", C_TEXT);
                    HelpT(r, "    размеров экрана, цветов, констант игры.\n", C_TEXT);

                    break;
                case 1:
                    HelpT(r, "\n═══ СИНТАКСИС Mini-C ═══════════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "\n  Типы:        int, void, bool\n", C_TEXT);
                    HelpT(r, "  Массивы:     int a[10];   int b[4][8];   bool flags[8];\n", C_TEXT);
                    HelpT(r, "  Инициализ.:  int x = 5;   bool f = true;   int a[10] = {0};\n", C_TEXT);
                    HelpT(r, "\n  bool:        хранится как 0/1, true=1, false=0\n", C_TEXT);
                    HelpT(r, "               bool ok = true;  if (ok) { ... }\n", C_TEXT);
                    HelpT(r, "\n  Операторы:   if / else / while / for / return / break / continue\n", C_TEXT);
                    HelpT(r, "  Скобки:      {} необязательны для одного оператора\n", C_TEXT);
                    HelpT(r, "\n  Арифметика:  + - * / %\n", C_TEXT);
                    HelpT(r, "  Сравнение:   == != < > <= >=\n", C_TEXT);
                    HelpT(r, "  Логика:      && || !\n", C_TEXT);
                    HelpT(r, "  Присвоение:  = += -= *= /=\n", C_TEXT);
                    HelpT(r, "  Унарные:     - ! ++ --\n", C_TEXT);

                    HelpT(r, "\n═══ СТРУКТУРЫ (struct) ══════════════════════════════════\n", Color.FromArgb(78, 201, 176));
                    HelpT(r, "\n  Объявление типа — только на верхнем уровне файла. Поле\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "  может быть массивом или другой структурой (вложенность):\n\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    struct Inner {\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        int a;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        int b;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    };\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    struct Tank {\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        struct Inner inner;    // вложенная структура\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        int scores[5];         // поле-массив\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        bool alive;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    };\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Переменная этого типа — глобально или внутри функции,\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "  можно сразу с инициализатором (по порядку полей):\n\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    struct Tank player;              // глобальная, нули\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "\n    void f() {\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "        struct Tank local = {..};   // локальная\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    }\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Доступ к полю — через точку, цепочкой сколько угодно:\n\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    player.scores[0] = 10;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    player.inner.a = player.inner.a + 1;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    if (player.alive) { ... }\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Присваивание структуры целиком — переменная в переменную,\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "  того же типа, копируются все поля:\n\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    struct Tank a;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    struct Tank b;\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    b = a;   // независимая копия, не ссылка\n\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Поля доступны из ЛЮБОЙ функции — так же, как обычные\n", C_TEXT);
                    HelpT(r, "  глобальные переменные, без дополнительной передачи.\n\n", C_TEXT);
                    HelpT(r, "\n  Пока НЕ поддерживается:\n\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "    • Структуры как параметры или возврат функции\n", C_TEXT);
                    HelpT(r, "    • Массивы структур (struct Tank arr[10])\n\n", C_TEXT);
                    HelpT(r, "  Каждое поле — минимум одно слово (2 байта); поле-массив\n", C_TEXT);
                    HelpT(r, "  и вложенная структура занимают столько слов, сколько\n", C_TEXT);
                    HelpT(r, "  нужно им самим. Локальная структура зануляется целиком\n", C_TEXT);
                    HelpT(r, "  при входе в блок, где объявлена (если нет инициализатора).\n", C_TEXT);

                    break;
                case 2:
                    HelpT(r, "\n═══ ВСТРОЕННЫЕ ФУНКЦИИ ══════════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpFn(r, "cls", "[mode]", "настройка экрана + очистка; mode 0..3 (0 по умолчанию)");
                    HelpFn(r, "pause", "", "пауза ~177777 итераций NOP");
                    HelpFn(r, "waitkey", "", "ждать клавишу → код (блокирующее)");
                    HelpFn(r, "getkey", "", "прочитать клавишу → код или 0 (неблокирующее)");
                    HelpFn(r, "sprite", "x,y,w,h,ptr", "спрайт из массива данных (MOV — перезапись)");
                    HelpFn(r, "spriteOr", "x,y,w,h,ptr", "спрайт через BIS (OR с экраном — прозрачность)");

                    break;
                case 3:
                    HelpT(r, "\n═══ ВЫВОД ТЕКСТА ════════════════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpFn(r, "print_int", "n", "вывод числа (со знаком)");
                    HelpFn(r, "print_char", "c", "вывод одного символа по коду ASCII");
                    HelpFn(r, "print_str", "s", "вывод строки: print_str(\"hello\")");
                    HelpFn(r, "print_nl", "", "перевод строки (CR)");
                    HelpFn(r, "printf", "fmt, ...", "форматный вывод: printf(\"x=%d c=%c\\n\", x, c)");
                    HelpT(r, "\n  Форматы printf:\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    %d  — целое число (print_int)\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    %c  — символ по коду (print_char)\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    %s  — строковый литерал (print_str)\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    \\n — перевод строки\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  Пример:\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    printf(\"x=%d, y=%d\\n\", x, y);\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "    printf(\"c=%c\\n\", 65);  // выведет c=A\n", Color.FromArgb(181, 206, 168));

                    break;
                case 4:
                    HelpT(r, "\n═══ ПОЗИЦИЯ И ЦВЕТ ТЕКСТА ═══════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpFn(r, "gotoxy", "x, y", "курсор в колонку x, строку y. Отсчёт с 0");
                    HelpFn(r, "setTextColor", "c", "цвет текста 0..7 (см. таблицу ниже)");
                    HelpFn(r, "setCursorColor", "c", "цвет курсора 0..7 (= фон, чтобы скрыть)");
                    HelpT(r, "\n  Цвета setTextColor (выверено на эмуляторе):\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    0 = чёрный    4 = зелёный\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    1 = синий     5 = cyan (голубой)\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    2 = красный   6 = жёлтый\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    3 = magenta   7 = белый\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  (биты: 1=синий, 2=красный, 4=зелёный — складываются)\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  Пример:\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "    setTextColor(6); gotoxy(10, 5); print_str(\"GOLD\");\n", Color.FromArgb(181, 206, 168));
                    HelpT(r, "  Внимание: текст и графику (cls) в одной программе мешать нельзя.\n", Color.FromArgb(200, 150, 100));

                    break;
                case 5:
                    HelpT(r, "\n═══ basicGraphic — пакет попиксельной графики ═══════════\n", Color.FromArgb(78, 201, 176));
                    HelpT(r, "  Фундамент: point(). Все остальные функции строятся поверх.\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  Экран: 320×264 (режим 0/2) или 640×264 (режим 1/3), 4 цвета.\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  Цвета: 0=чёрный  1=синий  2=зелёный  3=белый\n", Color.FromArgb(150, 150, 150));
                    HelpT(r, "  Клиппинг автоматический везде. Координаты в пикселях.\n\n", Color.FromArgb(150, 150, 150));
                    HelpFn(r, "point", "x, y, c", "пиксель — фундамент пакета. Нативный, максимальная скорость.");
                    HelpFn(r, "line", "x0,y0, x1,y1, c", "линия Брезенхэма. Нативный. Клиппинг Cohen-Sutherland.");
                    HelpFn(r, "rect", "x, y, w, h, c", "прямоугольник (контур). Нативный. 4 стороны через line.");
                    HelpFn(r, "fill_rect", "x, y, w, h, c", "залитый прямоугольник. Нативный. Словами + пиксели по краям.");
                    HelpFn(r, "circle", "cx, cy, r, c", "окружность (контур) радиуса r. Алгоритм Брезенхэма.");
                    HelpFn(r, "fill_dither", "x,y,w,h,pat,fg,bg", "заливка с дизерингом: паттерн pat (0..7) смешивает fg и bg.");
                    HelpFn(r, "random", "n", "случайное число 0..n-1. LFSR, период 65535. Быстрый.");
                    HelpFn(r, "vsync", "", "ждать тик таймера 50 Гц — стабильная скорость игр");
                    HelpFn(r, "sin256", "a", "синус: угол 0..255 = круг, результат -256..256");
                    HelpFn(r, "cos256", "a", "косинус: cos256(a) = sin256(a+64)");
                    HelpFn(r, "abs", "n", "модуль числа");
                    HelpFn(r, "min", "a, b", "минимум из двух");
                    HelpFn(r, "max", "a, b", "максимум из двух");
                    HelpFn(r, "clamp", "v, lo, hi", "ограничить v диапазоном [lo..hi]");

                    break;
                case 6:
                    HelpT(r, "\n═══ ЦВЕТА ══════════════════════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpKv(r, "0", "чёрный   (0)");
                    HelpKv(r, "1", "синий    (255)");
                    HelpKv(r, "2", "зелёный  (65280)");
                    HelpKv(r, "3", "белый    (65535)");

                    break;
                case 7:
                    HelpT(r, "\n═══ КЛАВИШИ УКНЦ (десятичные) ══════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpKv(r, "67", "→  вправо  (103 окт)");
                    HelpKv(r, "68", "←  влево   (104 окт)");
                    HelpKv(r, "65", "↑  вверх   (101 окт)");
                    HelpKv(r, "66", "↓  вниз    (102 окт)");
                    HelpKv(r, "32", "   пробел  ( 40 окт)");
                    HelpKv(r, "13", "   Enter   ( 15 окт)");

                    break;
                case 8:
                    HelpT(r, "\n═══ ЭКРАН УКНЦ ══════════════════════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "  Разрешение:  320 × 264 пикселей\n", C_TEXT);
                    HelpT(r, "  1 слово X  = 8 пикселей по горизонтали\n", C_TEXT);
                    HelpT(r, "  1 строка Y = 1 пиксель по вертикали\n", C_TEXT);
                    HelpT(r, "  Ширина:      40 слов (x: 0-39)\n", C_TEXT);
                    HelpT(r, "  Высота:      264 строки (y: 0-263)\n", C_TEXT);
                    HelpT(r, "  Клетка 2×32 = видимый прямоугольник 16×32 пикселей\n", C_TEXT);

                    break;
                case 9:
                    HelpT(r, "\n═══ ГОРЯЧИЕ КЛАВИШИ РЕДАКТОРА ══════════════════════════\n", Color.FromArgb(86, 156, 214));
                    HelpT(r, "  F5         — компилировать\n", C_TEXT);
                    HelpT(r, "  Ctrl+D     — дублировать строку\n", C_TEXT);
                    HelpT(r, "  Ctrl+/     — комментировать/раскомментировать\n", C_TEXT);
                    HelpT(r, "  Tab        — отступ 4 пробела (или сдвиг блока)\n", C_TEXT);
                    HelpT(r, "  Shift+Tab  — убрать отступ\n", C_TEXT);
                    HelpT(r, "  Enter      — автоотступ (доп. отступ после '{')\n", C_TEXT);
                    HelpT(r, "  Alt+↑ / ↓  — переместить строку вверх/вниз\n", C_TEXT);
                    HelpT(r, "  ( [ { \"     — автозакрытие пар (оборачивает выделение)\n", C_TEXT);
                    HelpT(r, "  Ctrl+Z/Y   — отмена/повтор\n", C_TEXT);
                    HelpT(r, "  Esc        — закрыть справку\n", C_TEXT);

                    break;

            }
        }


        private void HelpT(RichTextBox r, string s, Color c)
        {
            r.SelectionStart = r.TextLength;
            r.SelectionLength = 0;
            r.SelectionColor = c;
            r.AppendText(s);
        }

        private void HelpFn(RichTextBox r, string name, string args, string desc)
        {
            HelpT(r, "\n  ", C_TEXT);
            HelpT(r, name, Color.FromArgb(78, 201, 176));
            HelpT(r, "(" + args + ")", C_TEXT);
            HelpT(r, "  — " + desc, Color.FromArgb(120, 120, 120));
        }

        private void HelpKv(RichTextBox r, string key, string val)
        {
            HelpT(r, "  " + key, Color.FromArgb(181, 206, 168));
            HelpT(r, " = " + val + "\n", Color.FromArgb(120, 120, 120));
        }

        private void SetStatus(string msg, bool err)
        {
            _status.Text = msg;
            _status.ForeColor = err ? C_ERROR : C_OK;
        }

        // ── Горячие клавиши ───────────────────────────────────────
        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                Compile();
                e.Handled = true;
                return;
            }

            // Ctrl+D — дублировать строку
            if (e.Control && e.KeyCode == Keys.D)
            {
                DuplicateLine();
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }

            // Ctrl+/ — комментировать/раскомментировать
            if (e.Control && (e.KeyCode == Keys.Oem2 || e.KeyCode == Keys.OemQuestion))
            {
                ToggleComment();
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }

            // Alt+↑ / Alt+↓ — переместить строку
            if (e.Alt && e.KeyCode == Keys.Up)
            {
                MoveLine(-1);
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }
            if (e.Alt && e.KeyCode == Keys.Down)
            {
                MoveLine(1);
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }

            // Умный Backspace — удалить отступ 4 пробела разом
            if (e.KeyCode == Keys.Back && !e.Control && _src.SelectionLength == 0)
            {
                int ls = _src.GetFirstCharIndexOfCurrentLine();
                int caret = _src.SelectionStart;
                int col = caret - ls;
                if (col > 0 && col % 4 == 0)
                {
                    string line = _src.Lines.Length > 0 ? _src.Lines[_src.GetLineFromCharIndex(ls)] : "";
                    bool onlySpaces = true;
                    for (int k = 0; k < col && k < line.Length; k++)
                        if (line[k] != ' ') { onlySpaces = false; break; }
                    if (onlySpaces)
                    {
                        _src.Select(caret - 4, 4);
                        _src.SelectedText = "";
                        e.Handled = true; e.SuppressKeyPress = true;
                        return;
                    }
                }
            }

            // Over-type: если печатаем закрывающую скобку/кавычку, а она уже есть справа — перешагнуть
            if (!e.Control && !e.Alt && _src.SelectionLength == 0 && _src.SelectionStart < _src.TextLength)
            {
                char nextCh = _src.Text[_src.SelectionStart];
                char typed = '\0';
                if (e.KeyCode == Keys.OemCloseBrackets && e.Shift) typed = '}';
                else if (e.KeyCode == Keys.OemCloseBrackets && !e.Shift) typed = ']';
                else if (e.KeyCode == Keys.D0 && e.Shift) typed = ')';
                else if (e.KeyCode == Keys.OemQuotes && e.Shift) typed = '"';
                if (typed != '\0' && nextCh == typed)
                {
                    _src.SelectionStart = _src.SelectionStart + 1;
                    e.Handled = true; e.SuppressKeyPress = true;
                    return;
                }
            }

            // Tab — 4 пробела (или отступ выделения)
            if (e.KeyCode == Keys.Tab && !e.Control)
            {
                if (e.Shift) Unindent(); else IndentOrTab();
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }

            // Enter — автоотступ
            if (e.KeyCode == Keys.Enter && !e.Control)
            {
                AutoIndentNewline();
                e.Handled = true; e.SuppressKeyPress = true;
                return;
            }

            // Автозакрытие скобок и кавычек
            if (!e.Control && !e.Alt)
            {
                char open = '\0', close = '\0';
                if (e.KeyCode == Keys.OemOpenBrackets && e.Shift) { open = '{'; close = '}'; }
                else if (e.KeyCode == Keys.OemOpenBrackets && !e.Shift) { open = '['; close = ']'; }
                else if (e.KeyCode == Keys.D9 && e.Shift) { open = '('; close = ')'; }
                else if (e.KeyCode == Keys.OemQuotes && e.Shift) { open = '"'; close = '"'; }
                if (open != '\0')
                {
                    AutoClose(open, close);
                    e.Handled = true; e.SuppressKeyPress = true;
                    return;
                }
            }
        }

        // ── Tab → 4 пробела; для выделения — отступ блока ─────────
        private void IndentOrTab()
        {
            if (_src.SelectionLength > 0)
            {
                IndentBlock(true);
                return;
            }
            int col = _src.SelectionStart - _src.GetFirstCharIndexOfCurrentLine();
            int spaces = 4 - (col % 4);
            _src.SelectedText = new string(' ', spaces);
        }

        private void Unindent()
        {
            if (_src.SelectionLength > 0) { IndentBlock(false); return; }
            int lineStart = _src.GetFirstCharIndexOfCurrentLine();
            int lineIdx = _src.GetLineFromCharIndex(lineStart);
            string line = lineIdx < _src.Lines.Length ? _src.Lines[lineIdx] : "";
            int remove = 0;
            while (remove < 4 && remove < line.Length && line[remove] == ' ') remove++;
            if (remove > 0)
            {
                int caret = _src.SelectionStart;
                _src.Select(lineStart, remove);
                _src.SelectedText = "";
                _src.SelectionStart = Math.Max(lineStart, caret - remove);
            }
        }

        private void IndentBlock(bool add)
        {
            int selStart = _src.SelectionStart;
            int selEnd = selStart + _src.SelectionLength;
            int first = _src.GetLineFromCharIndex(selStart);
            int last = _src.GetLineFromCharIndex(selEnd);
            BeginRtbUpdate(_src);
            for (int i = last; i >= first; i--)
            {
                int ls = _src.GetFirstCharIndexFromLine(i);
                if (ls < 0) continue;
                if (add)
                {
                    _src.Select(ls, 0);
                    _src.SelectedText = "    ";
                }
                else
                {
                    string line = _src.Lines[i];
                    int rem = 0;
                    while (rem < 4 && rem < line.Length && line[rem] == ' ') rem++;
                    if (rem > 0) { _src.Select(ls, rem); _src.SelectedText = ""; }
                }
            }
            int newFirst = _src.GetFirstCharIndexFromLine(first);
            int newLast = _src.GetFirstCharIndexFromLine(last);
            int lastLen = (last < _src.Lines.Length) ? _src.Lines[last].Length : 0;
            _src.Select(newFirst, (newLast + lastLen) - newFirst);
            EndRtbUpdate(_src);
            Highlight();
        }

        // ── Enter с сохранением отступа + доп. отступ после '{' ──
        private void AutoIndentNewline()
        {
            int lineStart = _src.GetFirstCharIndexOfCurrentLine();
            int lineIdx = _src.GetLineFromCharIndex(lineStart);
            string line = lineIdx < _src.Lines.Length ? _src.Lines[lineIdx] : "";

            int indent = 0;
            while (indent < line.Length && line[indent] == ' ') indent++;

            string pad = new string(' ', indent);
            int caret = _src.SelectionStart;
            string trimmedBefore = line.Substring(0, Math.Min(caret - lineStart, line.Length)).TrimEnd();
            bool afterOpen = trimmedBefore.EndsWith("{");

            // Если курсор между { и } — раскрыть блок
            bool betweenBraces = afterOpen && caret < _src.TextLength && _src.Text[caret] == '}';

            if (betweenBraces)
            {
                string inner = pad + "    ";
                _src.SelectedText = "\n" + inner + "\n" + pad;
                _src.SelectionStart = caret + 1 + inner.Length;
            }
            else if (afterOpen)
            {
                string inner = pad + "    ";
                _src.SelectedText = "\n" + inner;
                _src.SelectionStart = caret + 1 + inner.Length;
            }
            else
            {
                _src.SelectedText = "\n" + pad;
                _src.SelectionStart = caret + 1 + pad.Length;
            }
        }

        // ── Автозакрытие парных символов ─────────────────────────
        private void AutoClose(char open, char close)
        {
            if (_src.SelectionLength > 0)
            {
                // обернуть выделение
                string sel = _src.SelectedText;
                int st = _src.SelectionStart;
                _src.SelectedText = open + sel + close;
                _src.SelectionStart = st + 1;
                _src.SelectionLength = sel.Length;
                return;
            }
            int caret = _src.SelectionStart;
            _src.SelectedText = open.ToString() + close.ToString();
            _src.SelectionStart = caret + 1;
        }

        // ── Ctrl+/ — комментирование строк ───────────────────────
        private void ToggleComment()
        {
            int selStart = _src.SelectionStart;
            int selEnd = selStart + _src.SelectionLength;
            int first = _src.GetLineFromCharIndex(selStart);
            int last = _src.GetLineFromCharIndex(selEnd);

            // Решаем: добавлять или убирать (если ВСЕ строки закомментированы — убираем)
            bool allCommented = true;
            for (int i = first; i <= last; i++)
            {
                string l = _src.Lines[i].TrimStart();
                if (l.Length > 0 && !l.StartsWith("//")) { allCommented = false; break; }
            }

            BeginRtbUpdate(_src);
            for (int i = last; i >= first; i--)
            {
                int ls = _src.GetFirstCharIndexFromLine(i);
                if (ls < 0) continue;
                string line = _src.Lines[i];
                if (allCommented)
                {
                    int p = line.IndexOf("//");
                    if (p >= 0)
                    {
                        int rem = (p + 2 < line.Length && line[p + 2] == ' ') ? 3 : 2;
                        _src.Select(ls + p, rem);
                        _src.SelectedText = "";
                    }
                }
                else
                {
                    if (line.Trim().Length == 0) continue;
                    int indent = 0;
                    while (indent < line.Length && line[indent] == ' ') indent++;
                    _src.Select(ls + indent, 0);
                    _src.SelectedText = "// ";
                }
            }
            EndRtbUpdate(_src);
            Highlight();
        }

        // ── Alt+↑/↓ — переместить строку ─────────────────────────
        private void MoveLine(int dir)
        {
            int caret = _src.SelectionStart;
            int idx = _src.GetLineFromCharIndex(caret);
            int colInLine = caret - _src.GetFirstCharIndexFromLine(idx);
            var lines = new System.Collections.Generic.List<string>(_src.Lines);
            int target = idx + dir;
            if (target < 0 || target >= lines.Count) return;

            string tmp = lines[idx];
            lines[idx] = lines[target];
            lines[target] = tmp;

            BeginRtbUpdate(_src);
            _src.Text = string.Join("\n", lines);
            int newStart = _src.GetFirstCharIndexFromLine(target) + colInLine;
            _src.SelectionStart = Math.Min(newStart, _src.TextLength);
            EndRtbUpdate(_src);
            Highlight();
        }

        // ── Ctrl+D: дублировать текущую строку ───────────────────
        private void DuplicateLine()
        {
            int selStart = _src.SelectionStart;
            int lineIdx = _src.GetLineFromCharIndex(selStart);
            if (lineIdx < 0 || lineIdx >= _src.Lines.Length) return;

            string line = _src.Lines[lineIdx];
            int lineEnd = _src.GetFirstCharIndexFromLine(lineIdx) + line.Length;

            // Вставить перенос строки + копию после текущей строки
            _src.SelectionStart = lineEnd;
            _src.SelectionLength = 0;
            _src.SelectedText = "\n" + line;

            // Перевести курсор на начало новой строки
            _src.SelectionStart = lineEnd + 1;
            _src.SelectionLength = line.Length;
        }

        // ── Компиляция ────────────────────────────────────────────
        // Открыть редактор уровней Battle City — единственная игра пока,
        // но метод вынесен отдельно, чтобы пункты меню «Игры» просто
        // вызывали каждый свой такой метод, без копирования этой логики.
        private void OpenLevelEditor()
        {
            if (_levelEditor == null || _levelEditor.IsDisposed)
            {
                _levelEditor = new LevelEditor(code =>
                {
                    string text = _src.Text;
                    var startMatch = Regex.Match(text,
                        @"// ── Уровень[^\n]*\n(// [^\n]*\n)*");
                    if (startMatch.Success)
                    {
                        text = text.Substring(0, startMatch.Index)
                             + text.Substring(startMatch.Index + startMatch.Length);
                    }
                    _src.Text = code + "\n" + text;
                    _src.SelectionStart = 0;
                    Highlight();
                });
                UpdateLevelsPath();
            }
            if (_levelEditor.Visible)
                _levelEditor.BringToFront();
            else
                _levelEditor.Show(this);
        }

        private void OpenImageConverter()
        {
            if (_imageConverter == null || _imageConverter.IsDisposed)
                _imageConverter = new ImageConverter();
            if (_imageConverter.Visible)
                _imageConverter.BringToFront();
            else
                _imageConverter.Show(this);
        }

        private void UpdateSpritesPath()
        {
            if (_project != null)
            {
                string path = _project.SpritesFile;
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
                if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                    _spriteEditor.SpritesPath = path;
                _projectSpritesPath = path;
            }
            else
            {
                if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                    _spriteEditor.SpritesPath = null;
                _projectSpritesPath = null;
            }
        }

        // Файл уровней кладём рядом с файлом спрайтов, в той же папке
        // проекта — без отдельного поля в McProject, той же логикой,
        // что и SpritesFile, только другое имя файла.
        private void UpdateLevelsPath()
        {
            if (_project != null)
            {
                string spritesPath = _project.SpritesFile;
                string dir = System.IO.Path.GetDirectoryName(spritesPath);
                string path = System.IO.Path.Combine(dir, "levels.lvl");
                System.IO.Directory.CreateDirectory(dir);
                if (_levelEditor != null && !_levelEditor.IsDisposed)
                    _levelEditor.LevelsPath = path;
                _projectLevelsPath = path;
            }
            else
            {
                if (_levelEditor != null && !_levelEditor.IsDisposed)
                    _levelEditor.LevelsPath = null;
                _projectLevelsPath = null;
            }
        }


        private void Compile()
        {
            // Спрайты живут в отдельном окне редактора и пишутся на диск по
            // таймеру — без принудительного сохранения здесь компилятор мог
            // прочитать файл ДО того, как в него попали последние правки
            // (свежепойманный случай: новые спрайты, чёрный экран при
            // запуске, хотя в самом редакторе всё нарисовано верно).
            if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                _spriteEditor.SaveNow();
            if (_levelEditor != null && !_levelEditor.IsDisposed)
                _levelEditor.SaveNow();

            _linePanel.ErrorLine = -1;
            _linePanel.Invalidate();
            _src.SelectAll();
            _src.SelectionBackColor = C_BG;
            _src.SelectionLength = 0;

            _out.ForeColor = C_TEXT;
            _out.Clear();

            string src = _src.Text;
            AppEnvironment.LastCode = src;
            if (string.IsNullOrWhiteSpace(src))
            {
                SetStatus("⚠  Пустой исходный код", true);
                return;
            }

            try
            {
                int spriteLineOffset;
                string fullSrc = InjectSprites(src, out spriteLineOffset);
                int levelLineOffset;
                fullSrc = InjectLevels(fullSrc, out levelLineOffset);
                fullSrc = StdLib.Inject(fullSrc);       // встроенные Mini-C библиотеки

                var tokens = new Lexer(fullSrc).Tokenize();
                var ast = new Parser(tokens).ParseProgram();
                var cg = new CodeGen();
                cg.OptimizeRuntime = _chkOptimize == null || _chkOptimize.Checked;
                cg.Mode = _gameMode ? CodeGen.RtMode.Game : CodeGen.RtMode.Cpu;
                string asm = cg.Generate(ast);

                _out.ForeColor = C_TEXT;
                _out.Text = asm;
                int asmLines = asm.Split('\n').Length;
                SetStatus($"✔  OK  •  {asmLines} строк .mac", false);
                SetStatusBarInfo($"✓ Компиляция успешна  —  {asmLines} строк, {asm.Length} символов .mac");
                if (_statusBar != null) _statusBar.BackColor = C_ACCENT;
                ColorizeAsm();
                _lastGenerated = _out.Text;   // запомнить эталон: что сгенерировал компилятор
            }
            catch (Exception ex)
            {
                _out.ForeColor = C_ERROR;
                _out.Text = "ОШИБКА:\r\n\r\n" + ex.Message;
                SetStatus("✘  " + ex.Message, true);
                SetStatusBarInfo("✘ Ошибка компиляции");
                if (_statusBar != null) _statusBar.BackColor = C_ERROR;

                var m = Regex.Match(ex.Message, @"Строка\s+(\d+)");
                if (m.Success && int.TryParse(m.Groups[1].Value, out int lineNum))
                {
                    // Вычесть строки вставленного кода спрайтов и уровней
                    int spriteOffset;
                    string afterSprites = InjectSprites(src, out spriteOffset);
                    int levelOffset;
                    InjectLevels(afterSprites, out levelOffset);
                    int userLine = Math.Max(1, lineNum - spriteOffset - levelOffset);

                    _linePanel.ErrorLine = userLine;
                    _linePanel.Invalidate();

                    int idx = _src.GetFirstCharIndexFromLine(userLine - 1);
                    if (idx >= 0 && userLine - 1 < _src.Lines.Length)
                    {
                        _src.SelectionStart = idx;
                        _src.SelectionLength = _src.Lines[userLine - 1].Length;
                        _src.SelectionBackColor = Color.FromArgb(90, 25, 25);
                        _src.SelectionLength = 0;
                        _src.ScrollToCaret();
                    }
                }
            }
        }

        // ── Запуск в эмуляторе UKNCBTL ───────────────────────────
        // Пайплайн:
        //   Mini-C → [наш компилятор] → A.MAC
        //   Скопировать A.MAC в папку с UKNCBTL.exe, которая настроена для компиляции и запуска Эмулятора
        //   Запускаем Run.bat       
        private void RunInEmulator()
        {
            // 1. Найти UKNCBTL.exe — сначала из окружения машины
            string emulPath = _emulatorPath;
            if (string.IsNullOrEmpty(emulPath))
                emulPath = AppEnvironment.EmulatorPath;

            if (string.IsNullOrEmpty(emulPath) || !System.IO.File.Exists(emulPath))
            {
                string here = System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location);
                string candidate = System.IO.Path.Combine(here, "UKNCBTL.exe");
                if (System.IO.File.Exists(candidate))
                    emulPath = candidate;
                else
                {
                    using (var dlg = new OpenFileDialog
                    {
                        Title = "Укажите UKNCBTL.exe",
                        Filter = "UKNCBTL|UKNCBTL.exe|Все файлы|*.*"
                    })
                    {
                        if (dlg.ShowDialog() != DialogResult.OK) return;
                        emulPath = dlg.FileName;
                    }
                }
                // Сохраняем в окружение — больше не спрашиваем
                _emulatorPath = emulPath;
                AppEnvironment.EmulatorPath = emulPath;
            }
            string workDir = System.IO.Path.GetDirectoryName(emulPath);

            // 2. Решаем, что исполнять.
            //    Если текст правого окна совпадает с тем, что в нём сгенерировал
            //    компилятор (или окно ещё не трогали) — компилируем заново.
            //    Если пользователь ЗАМЕНИЛ код вручную (текст отличается от
            //    эталона) — исполняем ровно то, что в окне, без перекомпиляции.
            bool manual = _lastGenerated != null && _out.Text != _lastGenerated;
            if (!manual)
                Compile();
            if (string.IsNullOrWhiteSpace(_out.Text)) return;
            string macPath = System.IO.Path.Combine(workDir, "A.MAC");
            System.IO.File.WriteAllText(macPath, _out.Text, System.Text.Encoding.ASCII);

            string runbat = System.IO.Path.Combine(workDir, "Run.bat");
            System.DateTime started = System.DateTime.Now;
            RunProcess(runbat, "", workDir, out string macroOut);

            // 3. Показать путь к собранному .SAV в статусной строке
            string savPath = System.IO.Path.Combine(workDir, "A.SAV");
            if (System.IO.File.Exists(savPath))
            {
                var savTime = System.IO.File.GetLastWriteTime(savPath);
                long savSize = new System.IO.FileInfo(savPath).Length;
                if (savTime >= started.AddSeconds(-2))
                {
                    string spr = _lastSpriteBytes > 0 ? $"  •  спрайты: {_lastSpriteBytes} байт" : "";
                    SetStatus($"✔  A.SAV собран  •  {savSize} байт{spr}  •  {savPath}", false);
                }
                else
                    SetStatus($"⚠  A.SAV НЕ обновился (старый от {savTime:HH:mm:ss})  •  {savPath}", true);
            }
            else
            {
                SetStatus($"⚠  A.SAV не найден в {workDir} — проверь Run.bat", true);
            }


        }



        private bool RunProcess(string exe, string args, string workDir, out string output)
        {
            var sb = new System.Text.StringBuilder();
            try
            {
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = args,
                    WorkingDirectory = workDir,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                var proc = System.Diagnostics.Process.Start(psi);
                string stdout = "", stderr = "";
                var t1 = new System.Threading.Thread(() => stdout = proc.StandardOutput.ReadToEnd());
                var t2 = new System.Threading.Thread(() => stderr = proc.StandardError.ReadToEnd());
                t1.Start(); t2.Start();
                bool done = proc.WaitForExit(30000);
                if (!done) { proc.Kill(); output = "[timeout]"; return false; }
                t1.Join(3000); t2.Join(3000);
                sb.Append(stdout); sb.Append(stderr);
                output = sb.ToString();
                return proc.ExitCode == 0;
            }
            catch (Exception ex) { output = ex.Message; return false; }
        }

        private bool RunProcess(string exe, string args, string workDir)
        {
            return RunProcess(exe, args, workDir, out _);
        }

        private string FindTool(string emulDir, string name)
        {
            foreach (var dir in new[]
            {
                emulDir,
                System.IO.Path.GetDirectoryName(emulDir),
                System.IO.Path.Combine(emulDir, "tools"),
                System.IO.Path.Combine(emulDir, "utils"),
            })
            {
                if (dir == null) continue;
                string p = System.IO.Path.Combine(dir, name);
                if (System.IO.File.Exists(p)) return p;
            }
            return null;
        }

        private string FindDiskImage(string emulDir, string workDir)
        {
            foreach (var dir in new[] { emulDir,
                System.IO.Path.GetDirectoryName(emulDir),
                workDir })
            {
                if (dir == null) continue;
                foreach (var ext in new[] { "*.dsk", "*.rtd", "*.img" })
                    foreach (var f in System.IO.Directory.GetFiles(dir, ext))
                        return f;
            }
            return null;
        }

        // ── Встроенная Mini-C библиотека ─────────────────────────
        // Функции добавляются автоматически если используются в коде.
        private string InjectSprites(string src, out int lineOffset)
        {
            lineOffset = 0;
            string spriteCode = BuildSpriteCode(src);
            if (string.IsNullOrEmpty(spriteCode)) return src;

            // Вставляем перед первой функцией (первое вхождение типа + имя + '(')
            var m = Regex.Match(src, @"^\s*(void|int)\s+\w+\s*\(", RegexOptions.Multiline);
            int insertPos = m.Success ? m.Index : 0;

            // Смещение строк — сколько строк в spriteCode
            lineOffset = spriteCode.Split('\n').Length;

            return src.Substring(0, insertPos) + spriteCode + "\n" + src.Substring(insertPos);
        }

        private string BuildSpriteCode(string src)
        {
            var mentioned = new System.Collections.Generic.HashSet<string>();
            foreach (Match m in Regex.Matches(src, @"//\s*sprite:\s*(\w+)"))
                mentioned.Add(m.Groups[1].Value);
            _lastSpriteBytes = 0;
            if (mentioned.Count == 0) return "";

            List<Sprite> sprites = null;
            if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                sprites = _spriteEditor.GetSprites();
            else
                sprites = LoadSpritesFromFile();

            if (sprites == null) sprites = new List<Sprite>();

            var missing = new System.Collections.Generic.List<string>();
            var found = new System.Collections.Generic.HashSet<string>();
            foreach (var s in sprites) found.Add(s.Name);
            foreach (var name in mentioned)
                if (!found.Contains(name)) missing.Add(name);
            if (missing.Count > 0)
                SetStatus($"⚠  Спрайты не найдены: {string.Join(", ", missing)}", true);

            // Собрать объявления спрайтов + посчитать их размер в памяти УКНЦ
            var sb = new System.Text.StringBuilder();
            _lastSpriteBytes = 0;
            foreach (var s in sprites)
                if (mentioned.Contains(s.Name))
                {
                    sb.AppendLine(s.ExportC());
                    _lastSpriteBytes += s.Words * s.Height * 2;  // слов × 2 байта
                }
            return sb.ToString();
        }

        private List<Sprite> LoadSpritesFromFile()
        {
            try
            {
                var _asp = _projectSpritesPath ?? ((_spriteEditor != null && !_spriteEditor.IsDisposed) ? _spriteEditor.SpritesPath : SpriteEditor.AutoSavePath);
                if (!System.IO.File.Exists(_asp)) return null;
                var text = System.IO.File.ReadAllText(_asp, System.Text.Encoding.UTF8);
                text = text.Replace("\r\n", "\n");
                var blocks = text.Split(new[] { "---\n" }, StringSplitOptions.RemoveEmptyEntries);
                var result = new List<Sprite>();
                foreach (var b in blocks)
                {
                    var sp = Sprite.Deserialize(b);
                    if (sp.Pixels != null && sp.Pixels.Length == sp.PixelWidth * sp.Height)
                        result.Add(sp);
                }
                return result;
            }
            catch { return null; }
        }

        // ── Уровни — та же схема, что и спрайты: комментарий // level: Имя
        //   в исходнике заменяется на реальный int Имя[...] = {...} перед
        //   компиляцией. Живой редактор — приоритет, файл — запасной путь.
        private string InjectLevels(string src, out int lineOffset)
        {
            lineOffset = 0;
            string levelCode = BuildLevelCode(src);
            if (string.IsNullOrEmpty(levelCode)) return src;

            var m = Regex.Match(src, @"^\s*(void|int)\s+\w+\s*\(", RegexOptions.Multiline);
            int insertPos = m.Success ? m.Index : 0;
            lineOffset = levelCode.Split('\n').Length;
            return src.Substring(0, insertPos) + levelCode + "\n" + src.Substring(insertPos);
        }

        private string BuildLevelCode(string src)
        {
            var mentioned = new HashSet<string>();
            foreach (Match m in Regex.Matches(src, @"//\s*level:\s*(\w+)"))
                mentioned.Add(m.Groups[1].Value);
            if (mentioned.Count == 0) return "";

            List<LevelMap> levels = null;
            if (_levelEditor != null && !_levelEditor.IsDisposed)
                levels = _levelEditor.GetLevels();
            else
                levels = LoadLevelsFromFile();
            if (levels == null) levels = new List<LevelMap>();

            var missing = new List<string>();
            var found = new HashSet<string>();
            foreach (var lv in levels) found.Add(lv.Name);
            foreach (var name in mentioned)
                if (!found.Contains(name)) missing.Add(name);
            if (missing.Count > 0)
                SetStatus($"⚠  Уровни не найдены: {string.Join(", ", missing)}", true);

            var sb = new StringBuilder();
            bool anyLevel = false;
            foreach (var lv in levels)
                if (mentioned.Contains(lv.Name)) { anyLevel = true; break; }
            if (anyLevel)
                sb.AppendLine(LevelMap.ExportStructDecl());   // тип struct Level — один раз, до самих уровней
            foreach (var lv in levels)
                if (mentioned.Contains(lv.Name))
                    sb.AppendLine(lv.ExportC());
            return sb.ToString();
        }

        private List<LevelMap> LoadLevelsFromFile()
        {
            try
            {
                if (string.IsNullOrEmpty(_projectLevelsPath) || !System.IO.File.Exists(_projectLevelsPath))
                    return null;
                var text = System.IO.File.ReadAllText(_projectLevelsPath, System.Text.Encoding.UTF8);
                text = text.Replace("\r\n", "\n");
                var blocks = text.Split(new[] { "---\n" }, StringSplitOptions.RemoveEmptyEntries);
                var result = new List<LevelMap>();
                foreach (var b in blocks)
                    if (b.Trim().Length > 0) result.Add(LevelMap.Deserialize(b));
                return result;
            }
            catch { return null; }
        }

        // ── Подсветка Mini-C ──────────────────────────────────────
        private static readonly HashSet<string> KwTypes = new HashSet<string> { "int", "void", "bool" };
        private static readonly HashSet<string> KwControl = new HashSet<string> { "if", "else", "while", "for", "return", "break", "continue" };
        private static readonly HashSet<string> KwBuiltin = new HashSet<string>(
            new[]{"cls","sprite","spriteOr","point","circle","print",
                  "waitkey","getkey","getTimer","pause","init","fillhline"})
        { };
        static Form1()
        {
            foreach (var n in StdLib.Names) KwBuiltin.Add(n);
            // ── Функции для файлового менеджера (Norton Commander) ──
            KwBuiltin.Add("fdelete");
            KwBuiltin.Add("frename");
            KwBuiltin.Add("mkdir");
            KwBuiltin.Add("getcwd");
            KwBuiltin.Add("chdir");
            KwBuiltin.Add("file_info");
        }
        private static readonly HashSet<string> KwBool = new HashSet<string> { "true", "false" };

        // Имена спрайтов для подсветки — обновляются из редактора/файла
        private HashSet<string> GetSpriteNames()
        {
            var names = new HashSet<string>();
            List<Sprite> sprites = null;
            if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                sprites = _spriteEditor.GetSprites();
            else
                sprites = LoadSpritesFromFile();
            if (sprites != null)
                foreach (var s in sprites) names.Add(s.Name);
            return names;
        }

        private void Highlight()
        {
            if (_highlighting) return;
            _highlighting = true;

            int sel = _src.SelectionStart;
            var scrollPos = GetRtbScroll(_src);       // запомнить прокрутку

            // ── Виртуализация: подсвечиваем только ВИДИМЫЕ строки + запас ──
            // Нагрузка перестаёт зависеть от размера файла.
            int topCharIdx = _src.GetCharIndexFromPosition(new System.Drawing.Point(1, 1));
            int botCharIdx = _src.GetCharIndexFromPosition(
                new System.Drawing.Point(1, Math.Max(1, _src.ClientSize.Height - 2)));
            int firstLine = _src.GetLineFromCharIndex(topCharIdx);
            int lastLine = _src.GetLineFromCharIndex(botCharIdx);
            int totalLines = _src.Lines.Length;
            const int MARGIN = 40;                       // запас строк сверху/снизу
            firstLine = Math.Max(0, firstLine - MARGIN);
            lastLine = Math.Min(Math.Max(0, totalLines - 1), lastLine + MARGIN);

            int winStart = _src.GetFirstCharIndexFromLine(firstLine);
            if (winStart < 0) winStart = 0;
            int lastLineStart = _src.GetFirstCharIndexFromLine(lastLine);
            int winEnd = (lastLineStart < 0)
                ? _src.TextLength
                : lastLineStart + (lastLine < totalLines ? _src.Lines[lastLine].Length : 0);
            if (winEnd > _src.TextLength) winEnd = _src.TextLength;
            int winLen = winEnd - winStart;
            if (winLen <= 0) { _highlighting = false; return; }

            BeginRtbUpdate(_src);

            // Берём ТОЛЬКО видимое окно, а не весь _src.Text
            string text = _src.Text.Substring(winStart, winLen);
            int n = text.Length;
            var spans = new System.Collections.Generic.List<(int s, int l, Color c)>(256);

            int i = 0;
            while (i < n)
            {
                char ch = text[i];

                if (ch == '/' && i + 1 < n && text[i + 1] == '/')
                {
                    int start = i;
                    while (i < n && text[i] != '\n') i++;
                    spans.Add((start, i - start, C_COMMENT));
                    continue;
                }
                if (ch == '/' && i + 1 < n && text[i + 1] == '*')
                {
                    int start = i; i += 2;
                    while (i < n - 1 && !(text[i] == '*' && text[i + 1] == '/')) i++;
                    i += 2;
                    if (i > n) i = n;
                    spans.Add((start, i - start, C_COMMENT));
                    continue;
                }
                if (char.IsDigit(ch) && (i == 0 || !char.IsLetterOrDigit(text[i - 1])))
                {
                    int start = i;
                    while (i < n && char.IsDigit(text[i])) i++;
                    if (i >= n || !char.IsLetter(text[i]))
                        spans.Add((start, i - start, C_NUMBER));
                    continue;
                }
                if (char.IsLetter(ch) || ch == '_')
                {
                    int start = i;
                    while (i < n && (char.IsLetterOrDigit(text[i]) || text[i] == '_')) i++;
                    string word = text.Substring(start, i - start);
                    if (KwTypes.Contains(word)) spans.Add((start, i - start, C_TYPE));
                    else if (KwControl.Contains(word)) spans.Add((start, i - start, C_KEYWORD));
                    else if (KwBuiltin.Contains(word)) spans.Add((start, i - start, C_ACCENT));
                    else if (KwBool.Contains(word)) spans.Add((start, i - start, C_NUMBER));
                    continue;
                }
                i++;
            }

            // Сброс цвета только в видимом окне, затем спаны (смещены на winStart)
            _src.Select(winStart, winLen);
            _src.SelectionColor = C_TEXT;
            foreach (var (s, l, c) in spans)
            {
                _src.SelectionStart = winStart + s;
                _src.SelectionLength = l;
                _src.SelectionColor = c;
            }

            // Восстановить каретку без прокрутки (окно не двигаем — красили видимое)
            _src.SelectionStart = sel;
            _src.SelectionLength = 0;
            _src.SelectionColor = C_TEXT;

            SetRtbScroll(_src, scrollPos);            // вернуть прокрутку на место
            EndRtbUpdate(_src);
            _highlighting = false;
        }

        private void PaintSrc(int start, int len, Color color)
        {
            _src.SelectionStart = start;
            _src.SelectionLength = len;
            _src.SelectionColor = color;
        }

        // ── Подсветка Macro-11 ────────────────────────────────────
        private static readonly string[] AsmOps =
        {
            "MOV","CLR","INC","DEC","NEG","TST","CMP","ADD","SUB","MUL","DIV",
            "ASL","ASR","JSR","RTS","BR","BEQ","BNE","BLT","BGT","BLE","BGE",
            "JMP","SOB","NOP","HALT","ROL","ROR"
        };
        private static readonly string[] AsmDir =
        {
            "\\.TITLE","\\.PSECT","\\.END","\\.WORD","\\.BLKW","\\.BYTE",
            "\\.EVEN","\\.MACRO","\\.ENDM","\\.MCall"
        };

        private void ColorizeAsm()
        {
            _out.SuspendLayout();
            BeginRtbUpdate(_out);

            _out.SelectAll();
            _out.SelectionColor = C_TEXT;
            string text = _out.Text;

            foreach (var d in AsmDir)
                foreach (Match m in Regex.Matches(text, d, RegexOptions.IgnoreCase))
                    PaintOut(m.Index, m.Length, C_TYPE);
            foreach (var op in AsmOps)
                foreach (Match m in Regex.Matches(text, $@"\b{op}\b"))
                    PaintOut(m.Index, m.Length, C_KEYWORD);
            foreach (Match m in Regex.Matches(text, @"^[A-Z][A-Z0-9]{0,5}:", RegexOptions.Multiline))
                PaintOut(m.Index, m.Length, C_OK);
            foreach (Match m in Regex.Matches(text, @"#-?\d+\."))
                PaintOut(m.Index, m.Length, C_NUMBER);
            foreach (Match m in Regex.Matches(text, @";[^\n]*"))
                PaintOut(m.Index, m.Length, C_COMMENT);
            foreach (Match m in Regex.Matches(text, @"\b(R[0-7]|SP|PC)\b"))
                PaintOut(m.Index, m.Length, C_TYPE);

            _out.SelectionStart = 0;
            _out.SelectionLength = 0;
            _out.SelectionColor = C_TEXT;

            EndRtbUpdate(_out);
            _out.ResumeLayout();
        }

        private void PaintOut(int start, int len, Color color)
        {
            _out.SelectionStart = start;
            _out.SelectionLength = len;
            _out.SelectionColor = color;
        }

        // ── Загрузка примера из файла ─────────────────────────────
        private static readonly string SamplePath =
            System.IO.Path.Combine(
                System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetExecutingAssembly().Location),
                "sample.c");

        // ── Режим компиляции: false = ЦП (векторная графика, 4 цвета),
        //    true = Game (320x264, связка ЦП+ПП, спрайтовая графика, 8 цветов) ──
        private bool _gameMode = false;
        private ModeSwitch _modeSwitch = null;   // переключатель ЦП/Game в панели
        private Label _modeLabel = null;

        // ── Галерея примеров ──────────────────────────────────────
        // Каждый пример: (категория, отображаемое имя, имя файла, краткое описание)
        private static readonly (string Cat, string Name, string File, string Desc)[] Examples = new[]
        {
            ("Графика", "DOOM — логотип",       "doom.c",        "Логотип DOOM проявляется через заполнение блоками"),
            ("Графика", "Волны",                "demo_waves.c",  "Две плавные синусоиды, лёгкая анимация"),
            ("Графика", "Спирограф",            "spiro.c",       "Плетёный узор Лиссажу, плавно прорастает"),
            ("Графика", "Звезда лучей",         "star.c",        "Вращающаяся звезда из лучей"),
            ("Графика", "3D-каркас",            "demo_3d.c",     "Вращающийся октаэдр (3D в реальном времени)"),
            ("Игры",    "Тетрис",               "tetris.c",      "Классический тетрис"),
            ("Игры",    "River Raid",           "riverraid.c",   "Скролл-шутер"),
            ("Игры",    "Match-3",              "match3.c",      "Три в ряд"),
            ("Базовые", "Стресс-тест",          "stress_test.c", "Все 33 встроенные функции и конструкции языка"),
            ("Базовые", "sample.c",             "sample.c",      "Базовый пример"),
        };

        // Папка с примерами: каталог рядом с exe (там же, где sample.c)
        private static string ExamplesDir =>
            System.IO.Path.GetDirectoryName(SamplePath);

        private void ShowExamplesMenu(Control anchor)
        {
            var menu = new ContextMenuStrip();
            menu.BackColor = Color.FromArgb(45, 45, 48);
            menu.ForeColor = Color.White;

            string lastCat = null;
            foreach (var ex in Examples)
            {
                if (lastCat != null && ex.Cat != lastCat)
                    menu.Items.Add(new ToolStripSeparator());
                lastCat = ex.Cat;

                var path = System.IO.Path.Combine(ExamplesDir, ex.File);
                bool exists = System.IO.File.Exists(path);

                var mi = new ToolStripMenuItem($"{ex.Name}")
                {
                    ToolTipText = ex.Desc + (exists ? "" : "  (файл не найден)"),
                    Enabled = exists
                };
                string p = path; string nm = ex.Name;
                mi.Click += (s2, e2) => LoadExample(p, nm);
                menu.Items.Add(mi);
            }

            menu.Show(anchor, new System.Drawing.Point(0, anchor.Height));
        }

        private void LoadExample(string path, string name)
        {
            try
            {
                _src.Text = System.IO.File.ReadAllText(path, System.Text.Encoding.UTF8);
                Highlight();
                SetStatus($"✓  Загружен пример: {name}", false);
            }
            catch (Exception ex)
            {
                SetStatus($"⚠  Не удалось загрузить {name}: {ex.Message}", true);
            }
        }

        private string LoadSample()
        {
            try
            {
                if (System.IO.File.Exists(SamplePath))
                    return System.IO.File.ReadAllText(SamplePath, System.Text.Encoding.UTF8);
                // Файл не найден — сообщить и вернуть пустой пример
                SetStatus($"⚠  Файл sample.c не найден: {SamplePath}", true);
                return $"// Файл sample.c не найден.\n// Ожидается по пути:\n// {SamplePath}\n";
            }
            catch (Exception ex)
            {
                SetStatus($"⚠  Ошибка чтения sample.c: {ex.Message}", true);
                return $"// Ошибка чтения sample.c:\n// {ex.Message}\n";
            }
        }

        // ── Пример (резервный — оставлен на случай отсутствия файла) ─
        private string Example() =>
@"// Поле 10x10, заполненное 1. Герой движется по стрелкам.
// Экран УКНЦ: 1 слово = 8 пикселей по X, 1 строка по Y.
// Клетка: 4 слова x 16 строк = 32x16 пикселей.
// Поле на экране: 40 слов x 160 строк.

// Нарисовать одну клетку поля
void drawCell(int x, int y, int color) {
    fill_rect(x * 32, y * 16, 32, 16, color);
}

// Отобразить героя в позиции (hx, hy)
void HERO(int hx, int hy) {
    drawCell(hx, hy, 3);
}

// Нарисовать всё поле
void drawField(int field[][10]) {
    int x = 0;
    int y = 0;
    for (y = 0; y < 10; y++) {
        for (x = 0; x < 10; x++) {
            drawCell(x, y, field[y][x]);
        }
    }
}

int main(void) {
    init();
    cls();

    int field[10][10] = {1};

    int hx = 0;
    int hy = 0;
    int k  = 0;

    drawField(field);
    HERO(hx, hy);

    while (k != 32) {
        k = getkey();

        if (k == 67) {
            if (hx < 9) {
                drawCell(hx, hy, field[hy][hx]);
                hx = hx + 1;
                HERO(hx, hy);
            }
        }
        if (k == 68) {
            if (hx > 0) {
                drawCell(hx, hy, field[hy][hx]);
                hx = hx - 1;
                HERO(hx, hy);
            }
        }
        if (k == 65) {
            if (hy > 0) {
                drawCell(hx, hy, field[hy][hx]);
                hy = hy - 1;
                HERO(hx, hy);
            }
        }
        if (k == 66) {
            if (hy < 9) {
                drawCell(hx, hy, field[hy][hx]);
                hy = hy + 1;
                HERO(hx, hy);
            }
        }
    }

    return 0;
}";


        // ── Методы работы с проектом ──────────────────────────────────

        private void ProjectNew()
        {
            if (!ProjectCheckSave()) return;
            var dlg = new NewProjectDialog();
            if (dlg.ShowDialog(this) != DialogResult.OK) return;
            if (string.IsNullOrWhiteSpace(dlg.ProjectName)) return;
            try
            {
                _project = McProject.CreateNew(dlg.ProjectName, dlg.ProjectFolder);
                RecentProjects.Add(_project.ProjectPath);
                AppEnvironment.LastProjectPath = _project.ProjectPath;
                LoadCodeIntoEditor(_project.ReadMainCode());
                UpdateSpritesPath();
                UpdateLevelsPath();
                _project.Settings.GameMode = _gameMode;   // текущий режим — стартовый для проекта
                _project.Save();
                if (_btnSave != null) _btnSave.Visible = true;
                UpdateTitle();
                SetStatus("✓ Проект создан: " + _project.Name, false);
            }
            catch (Exception ex) { MessageBox.Show("Ошибка создания проекта:\n" + ex.Message); }
        }

        private void ProjectOpenDialog()
        {
            if (!ProjectCheckSave()) return;
            var dlg = new OpenFileDialog
            {
                Title = "Открыть проект",
                Filter = "Проект Mini-C (*.pkc)|*.pkc",
                DefaultExt = "pkc"
            };
            if (dlg.ShowDialog(this) == DialogResult.OK)
                ProjectOpen(dlg.FileName);
        }

        private void ProjectOpen(string path)
        {
            if (!ProjectCheckSave()) return;
            try
            {
                _project = McProject.Load(path);
                RecentProjects.Add(path);
                AppEnvironment.LastProjectPath = path;
                LoadCodeIntoEditor(_project.ReadMainCode());
                UpdateSpritesPath();
                UpdateLevelsPath();
                ApplyProjectSettings();
                RestoreCaret();
                if (_btnSave != null) _btnSave.Visible = true;
                UpdateTitle();
                SetStatus("✓ Открыт: " + _project.Name, false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка открытия проекта:\n" + ex.Message);
                RecentProjects.Remove(path);
            }
        }

        // Пометить проект изменённым и показать это в заголовке
        private void MarkProjectDirty()
        {
            if (_project == null || _project.IsModified) return;
            _project.IsModified = true;
            UpdateTitle();
        }

        // Загрузить код в редактор, не помечая проект изменённым
        private void LoadCodeIntoEditor(string code)
        {
            _suppressDirty = true;
            try { _src.Text = code; }
            finally { _suppressDirty = false; }
        }

        // Применить к форме настройки открытого проекта
        private void ApplyProjectSettings()
        {
            if (_project == null) return;
            _gameMode = _project.Settings.GameMode;
            if (_modeSwitch != null) _modeSwitch.SetState(_gameMode);
            SetStatus(_gameMode
                ? "Режим Game: 320x264, спрайты, ЦП+ПП (8 цветов)"
                : "Режим ЦП: векторная графика, 4 цвета", false);
        }

        // Сбросить спрайты редактора в файл проекта и переписать их список в .pkc
        private void SaveProjectSprites()
        {
            if (_project == null) return;
            try
            {
                if (_spriteEditor != null && !_spriteEditor.IsDisposed)
                    _spriteEditor.SaveNow();

                _project.Sprites.Clear();
                var list = (_spriteEditor != null && !_spriteEditor.IsDisposed)
                    ? _spriteEditor.GetSprites()
                    : LoadSpritesFromFile();
                if (list != null)
                    foreach (var sp in list)
                        _project.Sprites.Add(sp.Name);
            }
            catch { /* спрайты не должны ронять сохранение проекта */ }
        }

        private void ProjectSave()
        {
            if (_project == null) return;
            _project.WriteMainCode(_src.Text);
            AppEnvironment.LastCode = _src.Text;

            SaveProjectSprites();

            // запомнить положение курсора
            int caret = _src.SelectionStart;
            int line = _src.GetLineFromCharIndex(caret);
            _project.CursorLine = line + 1;
            _project.CursorCol = caret - _src.GetFirstCharIndexFromLine(line) + 1;

            _project.Save();
            UpdateTitle();
            SetStatus("✓ Сохранено: " + _project.Name, false);
        }

        private void ProjectSaveAs()
        {
            if (_project == null) return;
            _project.WriteMainCode(_src.Text);

            // Выбираем папку назначения
            var dlg = new FolderBrowserDialog
            {
                Description = "Выберите папку для сохранения копии проекта",
                ShowNewFolderButton = true,
                SelectedPath = Path.GetDirectoryName(_project.ProjectDir)
            };
            if (dlg.ShowDialog(this) != DialogResult.OK) return;

            // Новый .pkc будет: выбранная папка / имя проекта / имя.pkc
            string newProjectDir = Path.Combine(dlg.SelectedPath, _project.Name);
            string newPkcPath = Path.Combine(newProjectDir, _project.Name + ".pkc");

            _project.SaveAs(newPkcPath);
            RecentProjects.Add(newPkcPath);
            AppEnvironment.LastProjectPath = newPkcPath;
            UpdateTitle();
            SetStatus("✓ Сохранено как: " + newPkcPath, false);
        }

        private void ProjectClose()
        {
            if (!ProjectCheckSave()) return;
            _project = null;
            UpdateSpritesPath();
            UpdateLevelsPath();
            if (_btnSave != null) _btnSave.Visible = false;
            UpdateTitle();
            SetStatus("Проект закрыт", false);
        }

        private bool ProjectCheckSave()
        {
            if (_project == null || !_project.IsModified) return true;
            var r = MessageBox.Show(
                "Проект \"" + _project.Name + "\" изменён. Сохранить?",
                "Сохранить проект?",
                MessageBoxButtons.YesNoCancel);
            if (r == DialogResult.Cancel) return false;
            if (r == DialogResult.Yes) ProjectSave();
            return true;
        }

        private void UpdateTitle()
        {
            if (_project == null) { Text = "Mini-C → Macro-11"; return; }
            Text = "Mini-C → Macro-11  |  " + _project.Name
                 + (_project.IsModified ? " ●" : "")
                 + (_project.Settings.GameMode ? "  [Game]" : "  [ЦП]");
        }

        // Вернуть курсор туда, где он был при сохранении проекта
        private void RestoreCaret()
        {
            if (_project == null) return;
            try
            {
                int line = Math.Max(0, _project.CursorLine - 1);
                if (line >= _src.Lines.Length) line = Math.Max(0, _src.Lines.Length - 1);
                int start = _src.GetFirstCharIndexFromLine(line);
                if (start < 0) start = 0;
                int col = Math.Max(0, _project.CursorCol - 1);
                if (line < _src.Lines.Length) col = Math.Min(col, _src.Lines[line].Length);
                _src.SelectionStart = Math.Min(start + col, _src.TextLength);
                _src.SelectionLength = 0;
                _src.ScrollToCaret();
            }
            catch { }
        }
    }

    // ── Переключатель режима ЦП/Game в стиле iOS (капсула с ползунком) ──
    internal class ModeSwitch : Control
    {
        public bool IsGame { get; private set; }
        public event Action<bool> Toggled;
        private float _pos = 0f;                    // 0 = ЦП, 1 = Game
        private readonly Timer _anim = new Timer { Interval = 15 };

        public ModeSwitch()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint |
                     ControlStyles.OptimizedDoubleBuffer, true);
            Size = new Size(104, 26);
            Cursor = Cursors.Hand;
            _anim.Tick += (s, e) =>
            {
                float target = IsGame ? 1f : 0f;
                _pos += (target - _pos) * 0.35f;    // плавное приближение
                if (Math.Abs(target - _pos) < 0.02f) { _pos = target; _anim.Stop(); }
                Invalidate();
            };
        }

        // Установить состояние без анимации (при открытии меню)
        public void SetState(bool game)
        {
            IsGame = game;
            _pos = game ? 1f : 0f;
            Invalidate();
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            IsGame = !IsGame;
            _anim.Start();
            Toggled?.Invoke(IsGame);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int w = Width - 1, h = Height - 1;
            // цвет капсулы: синий (ЦП) → зелёный (Game), интерполяция по позиции
            var c1 = Color.FromArgb(58, 110, 165);
            var c2 = Color.FromArgb(46, 160, 90);
            var cap = Color.FromArgb(
                (int)(c1.R + (c2.R - c1.R) * _pos),
                (int)(c1.G + (c2.G - c1.G) * _pos),
                (int)(c1.B + (c2.B - c1.B) * _pos));

            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                int r = h;                          // диаметр скругления = высота
                path.AddArc(0, 0, r, r, 90, 180);
                path.AddArc(w - r, 0, r, r, 270, 180);
                path.CloseFigure();
                using (var br = new SolidBrush(cap)) g.FillPath(br, path);
            }

            // подпись режима — на стороне, свободной от ползунка
            string txt = IsGame ? "Game" : "ЦП";
            var f = new Font("Segoe UI", 9f, FontStyle.Bold);
            var rect = IsGame
                ? new Rectangle(6, 0, w - h - 6, h + 1)          // слева от ползунка
                : new Rectangle(h, 0, w - h - 6, h + 1);         // справа от ползунка
            TextRenderer.DrawText(g, txt, f, rect, Color.White,
                TextFormatFlags.VerticalCenter |
                (IsGame ? TextFormatFlags.Left : TextFormatFlags.Right));

            // ползунок — белый круг с лёгкой тенью
            float kd = h - 6;
            float kx = 3 + _pos * (w - h);
            using (var sh = new SolidBrush(Color.FromArgb(60, 0, 0, 0)))
                g.FillEllipse(sh, kx + 1, 4.5f, kd, kd);
            g.FillEllipse(Brushes.White, kx, 3, kd, kd);
        }
    }
}